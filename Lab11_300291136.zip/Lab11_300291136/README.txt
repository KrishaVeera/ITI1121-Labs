Student name: Krisha Veera
Student number: 300291136
Course code: ITI1121
Lab section: C-2

This archive contains the 4 files of lab 11, that is, this file (README.txt),
plus Iterator.java, BitList.java, Iterative.java.
