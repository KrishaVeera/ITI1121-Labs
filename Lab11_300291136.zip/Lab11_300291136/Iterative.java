public class Iterative {

    public static BitList complement(BitList in) {

        return new BitList(in.toString().replace("1", "2").replace("0", "1").replace("2", "0"));
    }

    public static BitList or(BitList a, BitList b) {

        if (b.toString().length() == 0 || a.toString().length() == 0|| a.toString().length() != b.toString().length()) {
                    throw new IllegalArgumentException("Input bitstrings are empty or have different lengths");
        }
        BitList bl = new BitList();
        Iterator k = bl.iterator();
        Iterator i = a.iterator();
        Iterator j = b.iterator();
        if ( ! i.hasNext() ) {
            throw new IllegalArgumentException( "a is empty" );
       }
       if ( ! j.hasNext() ) {
            throw new IllegalArgumentException( "b is empty" );
       }
        while (i.hasNext() && j.hasNext()) {
            k.add(i.next() | j.next());
        }
        return bl;
    }

    public static BitList and(BitList a, BitList b) {
        if (b.toString().equals("") || a.toString().equals("") || a.toString().length() != b.toString().length()) {
            throw new IllegalArgumentException("Input bitstrings are empty or have different lengths");
        }
        
        
        BitList bl = new BitList();
        Iterator k = bl.iterator();
        Iterator i = a.iterator();
        Iterator j = b.iterator();
        if ( ! i.hasNext() ) {
            throw new IllegalArgumentException( "a is empty" );
       }
       if ( ! j.hasNext() ) {
            throw new IllegalArgumentException( "b is empty" );
       }
        while (i.hasNext() && j.hasNext()) {
            k.add(i.next() & j.next());
        }
        return bl;
        
    }

    public static BitList xor(BitList a, BitList b) {
        if (b.toString().length() == 0 || a.toString().length() == 0 || a.toString().length() != b.toString().length()) {
            throw new IllegalArgumentException("Input bitstrings are empty or have different lengths");
        }
        if (b.toString().length() == 0 || a.toString().length() == 0 || a.toString().length() != b.toString().length()) {
            throw new IllegalArgumentException("Input bitstrings are empty or have different lengths");
        }
        BitList bl = new BitList();
        Iterator k = bl.iterator();
        Iterator i = a.iterator();
        Iterator j = b.iterator();
        if ( ! i.hasNext() ) {
            throw new IllegalArgumentException( "a is empty" );
       }
       if ( ! j.hasNext() ) {
            throw new IllegalArgumentException( "b is empty" );
       }
        while (i.hasNext() && j.hasNext()) {
            k.add(i.next() ^ j.next());
        }
        return bl;
        
    }
}