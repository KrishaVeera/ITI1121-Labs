public class Rational {

    private int numerator;
    private int denominator;

    // constructor

    public Rational(int numerator) {
       this(numerator, 1);
    }

    public Rational(int numerator, int denominator) {
       int gcd = gcd(numerator, denominator);
       this.numerator = numerator / gcd;
       this.denominator = denominator / gcd;
       reduce();
    }

    // getters

    public int getNumerator() {
        return numerator;
    }

    public int getDenominator() {
        return denominator;
    }

    // instance methods

    public Rational plus(Rational other) {
       int numerator = this.numerator * other.denominator + this.denominator * other.numerator;
       int denominator = this.denominator * other.denominator;
       return new Rational(numerator, denominator);
    }

    public static Rational plus(Rational a, Rational b) {
       return a.plus(b);
    }

    // Transforms this number into its reduced form

    private void reduce() {
        int gcd = gcd(numerator, denominator);
        numerator /= gcd;
        denominator /= gcd;
    }

    // Euclid's algorithm for calculating the greatest common divisor
    private int gcd(int a, int b) {
        // Note that the loop below, as-is, will time out on negative inputs.
        // The gcd should always be a positive number.
        // Add code here to pre-process the inputs so this doesn't happen.
        a = Math.abs(a);
        b = Math.abs(b);
        while (a != b)
            if (a > b)
                a = a - b;
            else
                b = b - a;
        return a;
    }

    public int compareTo(Rational other) {
        int num1 = numerator * other.denominator;
        int num2 = other.numerator * denominator;
        return num1-num2;
    }

    public boolean equals(Rational other) {
        return this.compareTo(other) == 0;
    }

    public String toString() {
        String result;
        if (denominator == 1) {
            result = Integer.toString(numerator);
        } else {
           result = numerator + "/" + denominator;
        }
        return result;
    }

}