public class Combination {
    // Instance variables
    int x;
    int y;
    int z;

    // Constructor
    public Combination(int first, int second, int third) {
        x = first;
        y = second; 
        z = third;
    }

    // An instance method that compares this object
    // to other.
    // Always check that other is not null, i)
    // an error would occur if you tried to
    // access other.first if other was null, ii)
    // null is a valid argument, the method shouldz
    // simply return false.

    public boolean equals(Combination other) {
        // Put your code here and remove the line below
        if (other == null || this==null){
           return false; 
        }
        else if (x == other.x && y == other.y && z == other.z){
            return true;
        }
        else {
            return false;
        }
    }

  // Returns a String representation of this Combination.

    public String toString() {
        return x + ":" + y + ":" + z;
    }
}



