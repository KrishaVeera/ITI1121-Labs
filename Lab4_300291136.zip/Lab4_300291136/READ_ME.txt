Student name: Krisha Veera
Student number: 300291136
Lab section: C02

This archive contains the 6 files of lab 4, that is, this file (README.txt),
plus the files Likeable.java, Post.java, TextPost.java, PhotoPost.java, NewsFeed.java.