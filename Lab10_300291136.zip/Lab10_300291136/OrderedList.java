import java.util.NoSuchElementException;

public class OrderedList implements OrderedStructure {

    // Implementation of the doubly linked nodes (nested-class)

    private static class Node {

      	private Comparable value;
      	private Node previous;
      	private Node next;

      	private Node ( Comparable value, Node previous, Node next ) {
      	    this.value = value;
      	    this.previous = previous;
      	    this.next = next;
      	}
    }

    // Instance variables

    private Node head;
    private Node tail;
    private int size;

    // Representation of the empty list.

    public OrderedList() {
        
        head = null;
        tail = null;
        size = 0;

    }

    // Calculates the size of the list

    public int size() {
      	// Calculates the size of the list
    
        return size;        
    }


    public Object get( int pos ) {
        //Implement Object get( int pos ). It returns the element at the specified position in this OrderedList; the first element has the index 0. This operation must not change the state of the OrderedList.
        //Add test cases in the main program to validate the methods get and add. We are now in a better position to evaluate the method add, get and size. In particular we can add elements, and use a loop to access all the elements one after the other using get. Make sure that all the methods work properly before proceeding. Do not forget that get returns an element of type Object, you will therefore need to use a type cast.
        if (pos < 0 || pos >= size) {
            throw new IndexOutOfBoundsException();
        }
    
        Node currentNode = head;
        for (int i = 0; i < pos; i++) {
            currentNode = currentNode.next;
        }
    
        return currentNode.value;

    }

    // Adding an element while preserving the order

    public boolean add( Comparable o ) {
        //Implement the method boolean add( Comparable obj ); adds an element in increasing order according to the class’ natural comparison method (i.e. uses the method compareTo ). Returns true if the element can be successfully added to this OrderedList, and false otherwise.
        if (o == null) {
            throw new NullPointerException();
        }
    
        Node newNode = new Node(o, null, null);
    
        if (head == null) {
            head = newNode;
            tail = newNode;
            size++;
            return true;
        }
    
        Node currentNode = head;
    
        while (currentNode != null && currentNode.value.compareTo(o) < 0) {
            currentNode = currentNode.next;
        }
    
        if (currentNode == null) {
            newNode.previous = tail;
            tail.next = newNode;
            tail = newNode;
            size++;
            return true;
        }
    
        if (currentNode == head) {
            newNode.next = head;
            head.previous = newNode;
            head = newNode;
            size++;
            return true;
        }
    
        newNode.previous = currentNode.previous;
        newNode.next = currentNode;
        currentNode.previous.next = newNode;
        currentNode.previous = newNode;
        size++;
        return true;
        
    }

    //Removes one item from the position pos.

    public void remove( int pos ) {
        if (pos < 0 || pos >= size) {
            throw new IndexOutOfBoundsException();
        }
    
        if (head == tail) {
            head = null;
            tail = null;
            size--;
            return;
        }
    
        Node currentNode = head;
    
        for (int i = 0; i < pos; i++) {
            currentNode = currentNode.next;
        }
    
        if (currentNode == head) {
            head = head.next;
            head.previous = null;
            size--;
            return;
        }
    
        if (currentNode == tail) {
            tail = tail.previous;
            tail.next = null;
            size--;
            return;
        }
    
        currentNode.previous.next = currentNode.next;
        currentNode.next.previous = currentNode.previous;
        size--;
        

    }

    // Knowing that both lists store their elements in increasing
    // order, both lists can be traversed simultaneously.

    public void merge( OrderedList other ) {
        if (other == null) {
            throw new NullPointerException("The other list is null");
        }
        
        if (this.head == null) {
            this.head = other.head;
            this.tail = other.tail;
            this.size = other.size;
            return;
        }
        
        if (other.head == null) {
            return;
        }
        
        Node node1 = this.head;
        Node node2 = other.head;
        Node prev = null;
        
        while (node1 != null && node2 != null) {
            if (node1.value.compareTo(node2.value) <= 0) {
                prev = node1;
                node1 = node1.next;
            } else {
                Node next = node2.next;
                node2.next = node1;
                node2.previous = prev;
                
                if (prev == null) {
                    this.head = node2;
                } else {
                    prev.next = node2;
                }
                
                node1.previous = node2;
                prev = node2;
                node2 = next;
                this.size++;
            }
        }
        
        if (node1 == null && node2 != null) {
            prev.next = node2;
            node2.previous = prev;
            
            while (node2 != null) {
                this.size++;
                this.tail = node2;
                node2 = node2.next;
            }
        }


    }
}