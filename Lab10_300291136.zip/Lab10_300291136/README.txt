Student name: Krisha Veera
Student number: 300291136
Course code: ITI1121
Lab section: C - 02

This archive contains the 3 files of lab 10, that is, this file (README.txt),
plus OrderedStructure.java, OrderedList.java.