public class Account {
    private double balance;

    public Account(){
        balance = 0.0;
    }

    public void deposit(double amount){
        balance+= amount;
        System.out.println("New Balance: "+ balance);
    }

    public void withdraw(double amount) throws NotEnoughMoneyException{
        if(amount>balance){
            throw new NotEnoughMoneyException(amount,balance);
        }
        balance -= amount;
        System.out.println("New Balance: "+ balance);
    }

    public double getBalance(){
        return balance;
    }
}