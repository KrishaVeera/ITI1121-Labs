class FullStackException extends Exception{
    public FullStackException(){
        super("stack is full");
    }
}