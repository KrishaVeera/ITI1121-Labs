public class NotEnoughMoneyException extends IllegalStateException{
    private double amount;
    private double balance;

    public NotEnoughMoneyException(double amount, double balance){
        super("Cannot withdraw " + amount+"because balance is only "+ balance);
        this.amount = amount;
        this.balance = balance;
    }

    public double getAmount(){
        return amount;
    }

    public double getBalance(){
        return balance;
    }

    public double getMissingAmount(){
        return amount-balance;
    }
}