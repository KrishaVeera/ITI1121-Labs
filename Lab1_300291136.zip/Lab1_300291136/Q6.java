import java.util.Scanner;

public class Q6{
	public static void main(String[] args){
		double notes[] = new double[10];
		System.out.println("Enter the 10 marks here: ");
		Scanner scanDouble = new Scanner(System.in);
		for (int i = 0; i < 10; i++){
			notes[i] = scanDouble.nextDouble();
		}
		double average = calculateAverage(notes);
		double median = calculateMedian(notes);
		int failed = calculateNumberFailed(notes);
		int passed = calculateNumberPassed(notes);
		System.out.print("The average is "+average);
		System.out.print(", the median is "+median);
		System.out.print(", the amount of failed is "+failed);
		System.out.println(", the amount of passed is "+passed);
	}

	public static double calculateAverage(double[] notes){
		double y = 0;
		for (int i = 0; i < notes.length; i++){
			y = y + notes[i];
		}
		return (y/notes.length);
	}

	public static double calculateMedian(double[] notes){
		int i, j, arg;
		double tmp;
		for (i = 0; i < notes.length - 1; i++) {
			arg = i;
			for (j = i + 1; j < notes.length; j++) {
				if (notes[j] < notes[arg]) {
					arg = j;
				}
			}

			tmp = notes[arg];
			notes[arg] = notes[i];
			notes[i] = tmp;
		}
		double median = 0;
		int x  = 0;
		if (notes.length%2 == 0){
			x = notes.length /2;
			median = (notes[x] + notes[x-1])/2;
		}

		else{
			x = (notes.length/2);
			median = notes[x];
		}
		
		return median;
	}

	public static int calculateNumberFailed(double[] notes){
		int y = 0;
		for (int i = 0; i < notes.length; i++){
			if (notes[i] < 50.0){
				y++;
			}
		}
		return y;
	}

	public static int calculateNumberPassed(double[] notes){
		int y = 0;
		for (int i = 0; i < notes.length; i++){
			if (notes[i] >= 50.0){
				y++;
			}
		}
		return y;
	}

}