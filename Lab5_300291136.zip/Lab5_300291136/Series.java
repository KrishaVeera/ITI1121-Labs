public interface Series {
    //implementation
    public abstract double next();
}
