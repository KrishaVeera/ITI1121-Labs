import java.util.Comparator;

public class BookComparator implements Comparator<Book> {

    // Implement the comparator method for books.
    public int compare(Book b1, Book b2) {
        // Your code here
        if (b1.getAuthor().compareTo(b2.getAuthor()) != 0) {
            return b1.getAuthor().compareTo(b2.getAuthor());
        }
        if (b1.getTitle().compareTo(b2.getTitle()) != 0) {
            return b1.getTitle().compareTo(b2.getTitle());
        }
        if (b1.getYear() != b2.getYear()) {
            return b1.getYear() - b2.getYear();
        }
        return 0;
    }
    public boolean equals(Object other) {
        return this == other;
    }

}