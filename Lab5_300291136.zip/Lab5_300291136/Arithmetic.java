public class Arithmetic extends AbstractSeries {

    // instance variables
    double S = 1;
    double prev;

    public double next() {

        // implement the method
        double current = prev + S;
        prev = current;
        S++;
        return current; 
        
    }
}