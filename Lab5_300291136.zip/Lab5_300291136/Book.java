public class Book {

    // Your variables declaration here
    String author;
    String title;
    int year;

    public Book (String author, String title, int year) {
        // Your code here
        this.author = author;   
        this.title = title;
        this.year = year;
    }

    public String getAuthor() {
        // Your code here
        return this.author;
    }

    public String getTitle() {
        // Your code here
        return this.title;
    }

    public int getYear() {
        // Your code here
        return this.year;
    }

    public boolean equals(Object other) {
        // Your code here
        if (this == other) return true;
        if (other == null || getClass() != other.getClass()) return false;
        Book book = (Book) other;
        if (author==null||title==null){
            if (author!=null){
                return year == book.year && author.equals(book.author) && title==(book.title); 

            }else if (title!=null) {
                return year == book.year && author==(book.author) && title.equals(book.title);

            } else{
                return year == book.year && author==(book.author) && title==(book.title);
            }
            

        }
        return year == book.year && author.equals(book.author) && title.equals(book.title);


    }

    public String toString() {
        // Your code here
        return this.author + ": " + this.title + " (" + this.year + ")";
    }
}