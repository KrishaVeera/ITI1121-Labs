Student name: Krisha Veera
Student number: 300291136
Course code: ITI1121
Lab section: C-2

This archive contains the 5 files of lab 8, that is, this file (README.txt),
plus Queue.java, ArrayQueue.java, Customer.java, Cashier.java.